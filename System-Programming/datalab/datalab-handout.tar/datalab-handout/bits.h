
int bitNor(int, int);
int test_bitNor(int, int);


int copyLSB(int);
int test_copyLSB(int);


int isEqual(int, int);
int test_isEqual(int, int);


int bitMask(int, int);
int test_bitMask(int, int);


int bitCount(int);
int test_bitCount(int);


int tmax();
int test_tmax();


int isNonNegative(int);
int test_isNonNegative(int);


int addOK(int, int);
int test_addOK(int, int);


int rempwr2(int, int);
int test_rempwr2(int, int);


int isLess(int, int);
int test_isLess(int, int);


int absVal(int);
int test_absVal(int);


int isPower2(int);
int test_isPower2(int);


unsigned float_neg(unsigned);
unsigned test_float_neg(unsigned);


unsigned float_half(unsigned);
unsigned test_float_half(unsigned);


unsigned float_i2f(int);
unsigned test_float_i2f(int);




